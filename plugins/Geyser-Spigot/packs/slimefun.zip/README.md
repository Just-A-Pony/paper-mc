# RY-Slimefun-Geyser
[Slimefun-Geyser](https://github.com/SofiaRedmond/Slimefun-Geyser) 的一个fork,修复了 金苹果汁, 金块 (24克拉) 和 古代符文 [附魔] 并且完善了材质<br>
<br>
A fork of [Slimefun-Geyser](https://github.com/SofiaRedmond/Slimefun-Geyser) fixes golden apple juice, 24k gold block, and ancient rune enchantment, and improves textures
